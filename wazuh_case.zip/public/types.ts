export interface WazuhCaseManagementPluginSetup { }
export interface WazuhCaseManagementPluginStart { }

export interface Alert {
  _id: string;
  _source: {
    agent: {
      ip: string;
      name: string;
      id: string;
    };
    manager: {
      name: string;
    };
    rule: {
      id: string;
      description: string;
      level: number;
    };
    '@timestamp': string;
    status: 'open' | 'in progress' | 'closed';
    description?: string;
    caseID?: string;
    assignee?: string;
    updated_by?: string;
    updated_at?: string;
    [key: string]: any;
  };
}