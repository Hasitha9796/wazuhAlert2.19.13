import React from 'react';
import ReactDOM from 'react-dom';

// Local type aliases to avoid importing OpenSearch Dashboards internal types
type AppMountParameters = any;
type CoreStart = any;
type DataPublicPluginStart = any;
import { WazuhCaseManagementApp } from './components/app';

export const renderApp = (
  coreStart: CoreStart,
  dataStart: DataPublicPluginStart,
  { appBasePath, element }: AppMountParameters
) => {
  ReactDOM.render(
    <WazuhCaseManagementApp
      coreStart={coreStart}
      dataStart={dataStart}
      basename={appBasePath}
    />,
    element
  );

  return () => ReactDOM.unmountComponentAtNode(element);
};