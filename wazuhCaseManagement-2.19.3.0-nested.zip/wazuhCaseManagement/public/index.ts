import { WazuhCaseManagementPlugin } from './plugin';

export function plugin() {
  return new WazuhCaseManagementPlugin();
}