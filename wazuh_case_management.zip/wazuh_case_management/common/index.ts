export const PLUGIN_ID = 'wazuhCaseManagement';
export const PLUGIN_NAME = 'wazuh-case-management';