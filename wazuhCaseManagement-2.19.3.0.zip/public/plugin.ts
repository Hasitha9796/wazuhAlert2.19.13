// Use minimal local type aliases so this plugin can be type-checked outside
// of an OpenSearch Dashboards monorepo without depending on internal paths.
type AppMountParameters = any;
type CoreStart = any;
type CoreSetup<T = any> = any;
type Plugin<Setup = any, Start = any, A = any, B = any> = any;
type DataPublicPluginSetup = any;
type DataPublicPluginStart = any;
import { WazuhCaseManagementPluginSetup, WazuhCaseManagementPluginStart } from './types';
import { PLUGIN_ID, PLUGIN_NAME } from '../common/index';

interface WazuhCaseManagementPluginSetupDeps {
  data: DataPublicPluginSetup;
}

interface WazuhCaseManagementPluginStartDeps {
  data: DataPublicPluginStart;
}

export class WazuhCaseManagementPlugin
  implements Plugin<
    WazuhCaseManagementPluginSetup,
    WazuhCaseManagementPluginStart,
    WazuhCaseManagementPluginSetupDeps,
    WazuhCaseManagementPluginStartDeps
  > {
  public setup(
    core: CoreSetup<WazuhCaseManagementPluginStartDeps>,
    { data }: WazuhCaseManagementPluginSetupDeps
  ): WazuhCaseManagementPluginSetup {
    // Register an application into the side navigation menu
    core.application.register({
      id: PLUGIN_ID,
      title: 'Wazuh Case Management',
      async mount(params: AppMountParameters): Promise<() => any> {
        // Load application bundle
        const { renderApp } = await import('./application');
        // Get start services as specified in opensearch_dashboards.json
        const [coreStart, pluginsStart] = await core.getStartServices();
        // Render the application
        return renderApp(coreStart, (pluginsStart as WazuhCaseManagementPluginStartDeps).data, params);
      },
    });

    return {};
  }

  public start(core: CoreStart, { data }: WazuhCaseManagementPluginStartDeps): WazuhCaseManagementPluginStart {
    return {};
  }

  public stop() { }
}