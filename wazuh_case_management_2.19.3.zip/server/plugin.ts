import {
  PluginInitializerContext,
  CoreSetup,
  CoreStart,
  Plugin,
  Logger,
} from '......srccoreserver';

import { WazuhCaseManagementPluginSetup, WazuhCaseManagementPluginStart } from './types';
import { defineRoutes } from './routes';

export class WazuhCaseManagementPlugin
  implements Plugin<WazuhCaseManagementPluginSetup, WazuhCaseManagementPluginStart> {
  private readonly logger: Logger;

  constructor(initializerContext: PluginInitializerContext) {
    this.logger = initializerContext.logger.get();
  }

  public setup(core: CoreSetup) {
    this.logger.debug('wazuhCaseManagement: Setup');
    const router = core.http.createRouter();

    // Register server side APIs
    defineRoutes(router);

    return {};
  }

  public start(core: CoreStart) {
    this.logger.debug('wazuhCaseManagement: Started');
    return {};
  }

  public stop() {}
}
