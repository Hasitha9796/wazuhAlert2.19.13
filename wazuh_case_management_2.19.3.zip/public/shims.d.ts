declare module 'react';
declare module 'react-dom';

declare module '../../../src/core/public' {
  export type AppMountParameters = any;
  export type CoreStart = any;
  export type CoreSetup<T = any> = any;
  export type Plugin<Setup = any, Start = any, A = any, B = any> = any;
}

declare module '../../../../src/core/public' {
  export type AppMountParameters = any;
  export type CoreStart = any;
  export type CoreSetup<T = any> = any;
  export type Plugin<Setup = any, Start = any, A = any, B = any> = any;
}

declare module '../../../src/plugins/data/public' {
  export type DataPublicPluginStart = any;
  export type DataPublicPluginSetup = any;
}

declare module '../../../plugins/data/public' {
  export type DataPublicPluginStart = any;
  export type DataPublicPluginSetup = any;
}

declare module '../../../../src/plugins/data/public' {
  export type DataPublicPluginStart = any;
  export type DataPublicPluginSetup = any;
}

declare module '../common' {
  export const PLUGIN_ID: string;
  export const PLUGIN_NAME: string;
}
