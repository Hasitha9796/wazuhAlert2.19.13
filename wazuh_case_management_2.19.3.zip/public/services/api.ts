import { CoreStart } from '../../../../src/core/public';

export class AlertsApiService {
  constructor(private http: CoreStart['http']) { }

  async fetchAlertCounts(query?: string) {
    try {
      const queryBody: any = {
        size: 0,
        aggs: {
          status_counts: {
            terms: {
              field: 'status',
              size: 10
            }
          }
        }
      };

      if (query) {
        queryBody.query = {
          query_string: {
            query: query,
            analyze_wildcard: true
          }
        };
      } else {
        queryBody.query = { match_all: {} };
      }

      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: '/wazuh-alert-status/_search',
          method: 'GET',
        },
        body: JSON.stringify(queryBody),
      });
      return response;
    } catch (error) {
      console.error('Error fetching alert counts:', error);
      throw error;
    }
  }

  async fetchAlerts(query?: string, from: number = 0, size: number = 20) {
    try {
      const queryBody: any = {
        from,
        size,
        sort: [{ '@timestamp': { order: 'desc' } }],
      };

      if (query) {
        queryBody.query = {
          query_string: {
            query: query,
            analyze_wildcard: true
          }
        };
      } else {
        queryBody.query = { match_all: {} };
      }

      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: '/wazuh-alert-status/_search',
          method: 'GET',
        },
        body: JSON.stringify(queryBody),
      });
      return response;
    } catch (error) {
      console.error('Error fetching alerts:', error);
      throw error;
    }
  }

  async updateAlertStatus(alertId: string, status: string) {
    try {
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: `/wazuh-alert-status/_update/${alertId}`,
          method: 'POST',
        },
        body: JSON.stringify({
          doc: {
            status,
            updated_at: new Date().toISOString()
          }
        }),
      });
      return response;
    } catch (error) {
      console.error('Error updating alert:', error);
      throw error;
    }
  }

  async updateAlertDescription(alertId: string, description: string) {
    try {
      const user = await this.getCurrentUser().catch(() => 'unknown');
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: `/wazuh-alert-status/_update/${alertId}`,
          method: 'POST',
        },
        body: JSON.stringify({
          doc: {
            description,
            updated_at: new Date().toISOString(),
            updated_by: user
          }
        }),
      });
      return response;
    } catch (error) {
      console.error('Error updating alert description:', error);
      throw error;
    }
  }

  async getNextCaseId() {
    try {
      // Find the document with the highest caseID (lexicographical sort works for zero-padded fixed width IDs)
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: '/wazuh-alert-status/_search',
          method: 'GET',
        },
        body: JSON.stringify({
          size: 1,
          sort: [{ 'caseID.keyword': { order: 'desc', ignore_unmapped: true } }],
          _source: ['caseID']
        }),
      });

      const hits = response.hits?.hits || [];
      if (hits.length === 0 || !hits[0]._source?.caseID) {
        return '00000001';
      }

      const maxIdStr: string = hits[0]._source.caseID;
      const next = (parseInt(maxIdStr, 10) + 1).toString().padStart(8, '0');
      return next;
    } catch (error) {
      console.error('Error getting next case id:', error);
      throw error;
    }
  }

  async addUser(username: string) {
    try {
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: '/wazuh-case-users/_doc',
          method: 'POST',
        },
        body: JSON.stringify({ username }),
      });
      return response;
    } catch (error) {
      console.error('Error adding user:', error);
      throw error;
    }
  }

  async getUsers() {
    try {
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: '/wazuh-case-users/_search',
          method: 'GET',
        },
        body: JSON.stringify({ size: 1000 }),
      });

      return (response.hits?.hits || []).map((h: any) => ({ id: h._id, username: h._source.username }));
    } catch (error) {
      console.error('Error getting users:', error);
      throw error;
    }
  }

  async updateAlertAssignee(alertId: string, assignee: string) {
    try {
      const user = await this.getCurrentUser().catch(() => 'unknown');
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: `/wazuh-alert-status/_update/${alertId}`,
          method: 'POST',
        },
        body: JSON.stringify({
          doc: {
            assignee,
            updated_at: new Date().toISOString(),
            updated_by: user
          }
        }),
      });
      return response;
    } catch (error) {
      console.error('Error updating alert assignee:', error);
      throw error;
    }
  }

  async assignCaseId(alertId: string, caseID: string) {
    try {
      const user = await this.getCurrentUser().catch(() => 'unknown');
      const response = await this.http.post('/api/console/proxy', {
        query: {
          path: `/wazuh-alert-status/_update/${alertId}`,
          method: 'POST',
        },
        body: JSON.stringify({
          doc: {
            caseID,
            updated_at: new Date().toISOString(),
            updated_by: user
          }
        }),
      });
      return response;
    } catch (error) {
      console.error('Error assigning case id:', error);
      throw error;
    }
  }

  async getCurrentUser() {
    try {
      const resp = await this.http.get('/api/security/v1/me');
      // Try common shapes
      if (!resp) return 'unknown';
      if (resp.username) return resp.username;
      if (resp.user && resp.user.username) return resp.user.username;
      if (resp.user && resp.user.username) return resp.user.username;
      return 'unknown';
    } catch (error) {
      return 'unknown';
    }
  }
}